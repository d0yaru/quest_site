﻿<?
    if(!defined("Arizona")) return require_once '../../public/pages/404.php';
?>

<div class="layout__conten">
	<div class="error-page">
		<div class="container">
			<div class="http-error-page">
				<h1 class="http-error-page__title">Ошибка 404</h1> 
				<div class="http-error-page__subtitle">Страница не найдена</div>
			</div>
		</div>
	</div>
</div>